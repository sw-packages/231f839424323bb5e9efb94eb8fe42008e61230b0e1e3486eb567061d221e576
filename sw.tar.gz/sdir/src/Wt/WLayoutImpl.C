/*
 * Copyright (C) 2016 Emweb bv, Herent, Belgium.
 *
 * See the LICENSE file for terms of use.
 */

#include "Wt/WLayoutImpl.h"

namespace Wt {

WLayoutImpl::~WLayoutImpl()
{ }

}
